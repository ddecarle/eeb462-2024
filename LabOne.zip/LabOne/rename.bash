#!/bin/bash

oldNames="Ursus Dasypus Erinaceus Didelphis Ornithorhynchus Lepus Macropus Oryctolagus Crocuta Mus Equus Microtus Macaca Cavia Pteropus Canis Acinonyx Rattus"

newNames="bear armadillo hedgehog opossum platypus hare wallaby rabbit hyaena mouse horse vole macaque guineaPig flyingFox dingo cheetah rat"

old=($oldNames)
new=($newNames)


count=${#old[@]}
for i in `seq 1 $count`
do
    
	sed -i '' 's/^.*'${old[$i-1]}'.*$/>'${new[$i-1]}'/' 18s.fasta

done

