#!/usr/bin/python

def get_trees(file_name): # Makes a list of lines from file that start with "("
	#tree = file_name
	
	only_trees = []
	
	with open(file_name) as f:
		text = f.read()
	text = text.split("\n") # Makes a list
	for line in text:
		if line.startswith("(") == True:
			only_trees.append(line)
	#print only_trees	
	return only_trees


def regex_trees(text):
	import re

	p = re.compile("\[\d{1,3}\]")
	new1 = p.sub("", text) # Removes [] and numbers in [] as they are negatively supported

	p = re.compile(" ;")
	new2 = p.sub(";", new1) # Removes space before closing ;
	
	p = re.compile("=")
	new3 = p.sub(":", new2) # Changes = to :
 
	p = re.compile(" :")
	new4 = p.sub(":", new3) # Removes space before :

	p = re.compile(" \)")
	new5 = p.sub(")", new4) # Removes spaces before )

	p = re.compile(" ")
	new6 = p.sub(",", new5) # Replaces remaining spaces with ,

	p = re.compile("\)\(")
	new7 = p.sub("),(", new6) # Adds , between )(

	p = re.compile("(:\d{1,3})/(\d{1,3})")
	new8 = p.sub("\\2\\1", new7) # Flips bootstrap and branch-length values

	p = re.compile("/")
	new9 = p.sub("", new8) # Remove /

	p = re.compile("\?")
	new10 = p.sub("", new9) # Remove ?

	#print "\n" + new10
	return new10


def tnttre_list():
	# Saves all .tnttree files in pwd to a list called tre_files
	import os

	tnttre_files = []
	tre_files = []

	all_files = os.listdir(os.getcwd())
	for i in all_files: # List with file names ending with tnttree
		if i.endswith("tnttre"):
			#print i
			tnttre_files.append(i)

	#print tnttre_files
	return tnttre_files


def write_trees(in_tree, tre_name): # Turns list into a string, does regex_trees(), and saves as a file
	done = get_trees(in_tree)
	tree_strings = "\n".join(done) # Turns list into string
	#print tree_strings
	tr_str = regex_trees(tree_strings)
	with open(tre_name, "w") as out_file:
		out_file.write(tr_str)

def tnt_all():
	all = tnttre_list()
	for i in all:
		i_tre = i + ".tre" # Makes output .tnttre.tre
		write_trees(i, i_tre)

tnt_all()
print ("Enjoy your trees!")

	




